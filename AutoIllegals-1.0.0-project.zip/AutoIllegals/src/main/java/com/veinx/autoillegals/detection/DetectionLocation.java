package com.veinx.autoillegals.detection;
public enum DetectionLocation { INVENTORY, HOTBAR, OFFHAND, ARMOR, ENDER_CHEST, CURSOR, GROUND, CONTAINER, PICKUP, CRAFTING, COMMAND, OTHER }
