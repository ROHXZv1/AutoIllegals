package com.veinx.autoillegals.config;

import com.veinx.autoillegals.AutoIllegals;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.time.Duration;
import java.util.*;

public final class ConfigManager {
    private final AutoIllegals plugin;
    private FileConfiguration config;
    private final Set<Material> illegal = EnumSet.noneOf(Material.class);

    public ConfigManager(AutoIllegals plugin) { this.plugin = plugin; }

    public void load() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        config = plugin.getConfig();
        illegal.clear();
        for (String raw : config.getStringList("illegal-items")) {
            try { illegal.add(Material.valueOf(raw.trim().toUpperCase(Locale.ROOT))); }
            catch (IllegalArgumentException ex) { plugin.getLogger().warning("Unknown material in illegal-items: " + raw); }
        }
    }

    public FileConfiguration get() { return config; }
    public Set<Material> getIllegalMaterials() { return Collections.unmodifiableSet(illegal); }
    public boolean enabled() { return config.getBoolean("settings.enabled", true); }
    public boolean autoBan() { return config.getBoolean("settings.automatic-ban", true); }
    public long scanIntervalTicks() { return Math.max(20L, config.getLong("settings.scan-interval-ticks", 100L)); }
    public boolean scanEnderChests() { return config.getBoolean("settings.scan-ender-chests", true); }
    public boolean scanGround() { return config.getBoolean("settings.scan-loaded-ground-items", true); }
    public boolean recursiveContainers() { return config.getBoolean("settings.recursive-container-scan", true); }
    public int maxContainerDepth() { return Math.max(0, config.getInt("settings.max-container-depth", 3)); }
    public boolean removeBeforeBan() { return config.getBoolean("settings.remove-item-before-ban", true); }
    public String bypassPermission() { return config.getString("bypass.permission", "autoillegals.bypass"); }
    public boolean operatorsBypass() { return config.getBoolean("bypass.operators", true); }
    public Set<UUID> trustedUuids() {
        Set<UUID> out = new HashSet<>();
        for (String s : config.getStringList("bypass.trusted-uuids")) try { out.add(UUID.fromString(s)); } catch (IllegalArgumentException ignored) {}
        return out;
    }
    public List<String> bypassWorlds() { return config.getStringList("bypass.worlds"); }
    public Duration banDuration() { return DurationParser.parse(config.getString("settings.ban-duration", "20d"), Duration.ofDays(20)); }
    public String banDurationText() { return config.getString("settings.ban-duration", "20d"); }
    public boolean alertsEnabled() { return config.getBoolean("alerts.enabled", true); }
    public String alertPermission() { return config.getString("alerts.permission", "autoillegals.alerts"); }
    public boolean defaultAlerts() { return config.getBoolean("alerts.default-enabled", true); }
    public boolean loggingEnabled() { return config.getBoolean("logging.enabled", true); }
    public boolean metadataLogging() { return config.getBoolean("logging.include-item-metadata", true); }
    public boolean debug() { return config.getBoolean("logging.debug", false); }

    public String msg(String path, Map<String,String> replacements) {
        String value = config.getString("messages." + path, "");
        for (var e : replacements.entrySet()) value = value.replace("%" + e.getKey() + "%", e.getValue());
        return org.bukkit.ChatColor.translateAlternateColorCodes('&', value);
    }

    public String msg(String path) { return msg(path, Map.of()); }

    public boolean checkEnabled(String check) { return config.getBoolean("checks." + check + ".enabled", false); }
    public String checkAction(String check) { return config.getString("checks." + check + ".action", "ALERT").toUpperCase(Locale.ROOT); }
    public int checkThreshold(String check) { return Math.max(1, config.getInt("checks." + check + ".threshold", 3)); }
    public double checkDouble(String check, String key, double def) { return config.getDouble("checks." + check + "." + key, def); }
    public int checkInt(String check, String key, int def) { return config.getInt("checks." + check + "." + key, def); }

    private static final class DurationParser {
        static Duration parse(String input, Duration fallback) {
            if (input == null) return fallback;
            String s = input.trim().toLowerCase(Locale.ROOT);
            try {
                if (s.matches("\\d+")) return Duration.ofSeconds(Long.parseLong(s));
                long total = 0;
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+)\\s*([smhdw])").matcher(s);
                int count = 0;
                while (m.find()) {
                    long n = Long.parseLong(m.group(1));
                    total += switch (m.group(2)) { case "s" -> n; case "m" -> n*60; case "h" -> n*3600; case "d" -> n*86400; case "w" -> n*604800; default -> 0; };
                    count++;
                }
                return count > 0 && total > 0 ? Duration.ofSeconds(total) : fallback;
            } catch (Exception ex) { return fallback; }
        }
    }
}
