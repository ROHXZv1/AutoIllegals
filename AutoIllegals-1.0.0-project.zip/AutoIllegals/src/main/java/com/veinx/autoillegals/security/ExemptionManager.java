package com.veinx.autoillegals.security;

import com.veinx.autoillegals.AutoIllegals;
import org.bukkit.World;
import org.bukkit.entity.Player;
import java.util.UUID;

public final class ExemptionManager {
    private final AutoIllegals plugin;
    public ExemptionManager(AutoIllegals plugin) { this.plugin = plugin; }
    public boolean bypass(Player p) {
        var c = plugin.config();
        if (c.operatorsBypass() && p.isOp()) return true;
        if (p.hasPermission(c.bypassPermission())) return true;
        if (c.trustedUuids().contains(p.getUniqueId())) return true;
        for (String world : c.bypassWorlds()) if (world.equalsIgnoreCase(p.getWorld().getName())) return true;
        return false;
    }
    public boolean bypassWorld(World world) { return cWorld(world.getName()); }
    private boolean cWorld(String name) { return plugin.config().bypassWorlds().stream().anyMatch(name::equalsIgnoreCase); }
}
