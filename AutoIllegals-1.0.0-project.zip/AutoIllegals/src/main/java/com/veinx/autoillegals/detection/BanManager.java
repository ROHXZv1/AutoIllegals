package com.veinx.autoillegals.detection;

import com.veinx.autoillegals.AutoIllegals;
import org.bukkit.entity.Player;
import java.util.Map;

public final class BanManager {
    private final AutoIllegals plugin;
    public BanManager(AutoIllegals plugin) { this.plugin = plugin; }

    public void ban(Player player, DetectionRecord record) {
        String reason = "Illegal item detected by AutoIllegals Anti-Cheat | Item: " + record.item().material();
        String playerMessage = plugin.config().msg("ban-player", Map.of(
                "item", record.item().material(), "duration", plugin.config().banDurationText()));
        // Paper 26.2 exposes native temporary profile bans on Player; this keeps the plugin
        // compatible with the server's normal ban list instead of maintaining a second ban database.
        player.ban(reason, plugin.config().banDuration(), "AutoIllegals Anti-Cheat", false);
        player.kickPlayer(playerMessage);
    }
}
