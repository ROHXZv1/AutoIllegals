package com.veinx.autoillegals;

import com.veinx.autoillegals.command.CommandManager;
import com.veinx.autoillegals.config.ConfigManager;
import com.veinx.autoillegals.detection.DetectionManager;
import com.veinx.autoillegals.listener.AntiCheatListener;
import com.veinx.autoillegals.listener.IllegalItemListener;
import com.veinx.autoillegals.logging.LogManager;
import com.veinx.autoillegals.security.AlertManager;
import com.veinx.autoillegals.security.ViolationManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public final class AutoIllegals extends JavaPlugin {
    private ConfigManager config;
    private LogManager logs;
    private AlertManager alerts;
    private ViolationManager violations;
    private DetectionManager detection;

    @Override public void onEnable() {
        config = new ConfigManager(this); config.load();
        logs = new LogManager(this);
        alerts = new AlertManager(this);
        violations = new ViolationManager(this);
        detection = new DetectionManager(this);

        var pm = getServer().getPluginManager();
        pm.registerEvents(new IllegalItemListener(this), this);
        pm.registerEvents(new AntiCheatListener(this), this);
        var commandManager = new CommandManager(this);
        getCommand("autoillegals").setExecutor(commandManager);
        getCommand("autoillegals").setTabCompleter(commandManager);

        startSafetyScanner();
        getLogger().info("================================");
        getLogger().info("AutoIllegals");
        getLogger().info("Illegal Item Security");
        getLogger().info("Version: " + getPluginMeta().getVersion());
        getLogger().info("Minecraft: 1.26.2");
        getLogger().info("Illegal Item Detection: " + (config.enabled() ? "ENABLED" : "DISABLED"));
        getLogger().info("Anti-Cheat Checks: ENABLED");
        getLogger().info("Automatic Bans: " + (config.autoBan() ? "ENABLED" : "DISABLED"));
        getLogger().info("Ban Duration: " + config.banDurationText());
        getLogger().info("================================");
    }

    public void restartRuntimeTasks() {
        Bukkit.getScheduler().cancelTasks(this);
        startSafetyScanner();
    }

    private void startSafetyScanner() {
        long period = config.scanIntervalTicks();
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (!config.enabled()) return;
            for (var player : Bukkit.getOnlinePlayers()) detection.scanPlayer(player, "PERIODIC_SAFETY_SCAN");
            if (config.scanGround()) {
                for (var world : Bukkit.getWorlds()) {
                    for (var entity : world.getEntitiesByClass(org.bukkit.entity.Item.class)) {
                        if (config.getIllegalMaterials().contains(entity.getItemStack().getType())) entity.remove();
                    }
                }
            }
        }, period, period);
    }

    @Override public void onDisable() { Bukkit.getScheduler().cancelTasks(this); }
    public ConfigManager config() { return config; }
    public LogManager logs() { return logs; }
    public AlertManager alerts() { return alerts; }
    public ViolationManager violations() { return violations; }
    public DetectionManager detection() { return detection; }
}
