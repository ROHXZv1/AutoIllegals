package com.veinx.autoillegals.detection;

import com.veinx.autoillegals.AutoIllegals;
import com.veinx.autoillegals.security.ExemptionManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.meta.BlockStateMeta;

import java.time.Instant;
import java.util.Map;
import java.util.Optional;

public final class DetectionManager {
    private final AutoIllegals plugin;
    private final InventoryScanner scanner;
    private final ExemptionManager exemptions;
    private final BanManager banManager;

    public DetectionManager(AutoIllegals plugin) {
        this.plugin = plugin;
        this.scanner = new InventoryScanner(plugin);
        this.exemptions = new ExemptionManager(plugin);
        this.banManager = new BanManager(plugin);
    }

    public InventoryScanner scanner() { return scanner; }

    public Optional<InventoryScanner.FoundItem> scanPlayer(Player player, String trigger) {
        if (!plugin.config().enabled() || exemptions.bypass(player)) return Optional.empty();
        Optional<InventoryScanner.FoundItem> result = scanner.scanPlayer(player, plugin.config().scanEnderChests());
        result.ifPresent(found -> handle(player, found.item(), found.source(), trigger, found));
        return result;
    }

    public void inspectItemEntity(Item entity, Player picker, DetectionLocation location) {
        if (!plugin.config().enabled() || picker == null || exemptions.bypass(picker)) return;
        ItemStack stack = entity.getItemStack();
        if (plugin.config().getIllegalMaterials().contains(stack.getType())) {
            handle(picker, stack, location, "GROUND_PICKUP", new InventoryScanner.FoundItem(stack, location, null, 0));
            entity.remove();
        }
    }

    public void inspectCandidate(Player player, ItemStack item, DetectionLocation source, String trigger) {
        if (!plugin.config().enabled() || item == null || exemptions.bypass(player)) return;
        if (plugin.config().getIllegalMaterials().contains(item.getType())) {
            handle(player, item, source, trigger, new InventoryScanner.FoundItem(item, source, null, 0));
        }
    }

    private void handle(Player player, ItemStack item, DetectionLocation source, String trigger, InventoryScanner.FoundItem found) {
        if (player.isOnline() && exemptions.bypass(player)) return;
        String metadata = plugin.config().metadataLogging() ? safeMetadata(item) : "disabled";
        Location loc = player.getLocation();
        DetectionRecord record = new DetectionRecord(player.getUniqueId(), player.getName(), DetectionRecord.MaterialInfo.of(item),
                item.getAmount(), source, loc.getWorld() == null ? "unknown" : loc.getWorld().getName(), loc.clone(), Instant.now(),
                plugin.config().autoBan() ? "TEMPORARY_BAN" : "REMOVED_ONLY", metadata);
        if (plugin.config().removeBeforeBan()) remove(player, found);
        plugin.logs().detection(record, item);
        plugin.getLogger().warning("Player " + player.getName() + " detected with illegal item " + item.getType().name());
        plugin.getLogger().warning("Location: " + source + " | Trigger: " + trigger);
        plugin.getLogger().warning("Action: " + (plugin.config().autoBan() ? "Item removed + " + plugin.config().banDurationText() + " ban" : "Item removed only"));
        plugin.alerts().send(record, trigger);
        if (plugin.config().autoBan()) banManager.ban(player, record);
    }

    private void remove(Player player, InventoryScanner.FoundItem found) {
        if (found.removal() != null) {
            var state = found.removal().meta().getBlockState();
            var inventory = found.removal().holder().getInventory();
            inventory.setItem(found.removal().slot(), null);
            state.update(true, false);
            return;
        }
        var type = found.item().getType();
        var inv = player.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack != null && stack.getType() == type) inv.setItem(i, null);
        }
        ItemStack cursor = player.getOpenInventory().getCursor();
        if (cursor != null && cursor.getType() == type) player.getOpenInventory().setCursor(null);
        if (plugin.config().scanEnderChests()) {
            Inventory ender = player.getEnderChest();
            for (int i = 0; i < ender.getSize(); i++) {
                ItemStack stack = ender.getItem(i);
                if (stack != null && stack.getType() == type) ender.setItem(i, null);
            }
        }
    }

    private String safeMetadata(ItemStack item) {
        try { return item.getItemMeta() == null ? "none" : item.getItemMeta().serialize().toString(); }
        catch (Exception ex) { return "unavailable"; }
    }
}
