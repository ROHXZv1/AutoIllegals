package com.veinx.autoillegals.security;

import com.veinx.autoillegals.AutoIllegals;
import org.bukkit.entity.Player;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ViolationManager {
    private final AutoIllegals plugin;
    private final Map<UUID, Map<String,Integer>> levels = new ConcurrentHashMap<>();
    public ViolationManager(AutoIllegals plugin) { this.plugin = plugin; }
    public int add(Player p, String check) {
        int vl = levels.computeIfAbsent(p.getUniqueId(), k -> new ConcurrentHashMap<>()).merge(check, 1, Integer::sum);
        int threshold = plugin.config().checkThreshold(check);
        String action = plugin.config().checkAction(check);
        if (vl >= threshold) apply(p, check, vl, action);
        return vl;
    }
    private void apply(Player p, String check, int vl, String action) {
        plugin.alerts().sendViolation(p, check, vl);
        if ("KICK".equals(action) && p.isOnline()) p.kickPlayer("AutoIllegals: suspicious " + check + " activity");
        if ("NONE".equals(action)) return;
    }
    public int get(Player p, String check) { return levels.getOrDefault(p.getUniqueId(), Map.of()).getOrDefault(check, 0); }
    public Map<String,Integer> all(Player p) { return Map.copyOf(levels.getOrDefault(p.getUniqueId(), Map.of())); }
    public void clear(Player p) { levels.remove(p.getUniqueId()); }
}
