package com.veinx.autoillegals.listener;

import com.veinx.autoillegals.AutoIllegals;
import com.veinx.autoillegals.detection.DetectionLocation;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;

public final class IllegalItemListener implements Listener {
    private final AutoIllegals plugin;
    public IllegalItemListener(AutoIllegals plugin) { this.plugin = plugin; }
    private void later(Player p, String trigger) { plugin.getServer().getScheduler().runTask(plugin, () -> plugin.detection().scanPlayer(p, trigger)); }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void click(InventoryClickEvent e) { if (e.getWhoClicked() instanceof Player p) later(p, "INVENTORY_CLICK"); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void drag(InventoryDragEvent e) { if (e.getWhoClicked() instanceof Player p) later(p, "INVENTORY_DRAG"); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void open(InventoryOpenEvent e) { if (e.getPlayer() instanceof Player p) later(p, "INVENTORY_OPEN"); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void move(InventoryMoveItemEvent e) { if (plugin.config().getIllegalMaterials().contains(e.getItem().getType())) e.setCancelled(true); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void craft(CraftItemEvent e) { if (e.getWhoClicked() instanceof Player p) later(p, "CRAFTING"); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void creative(InventoryCreativeEvent e) { if (e.getWhoClicked() instanceof Player p) later(p, "CREATIVE_INVENTORY"); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void drop(PlayerDropItemEvent e) { plugin.detection().inspectCandidate(e.getPlayer(), e.getItemDrop().getItemStack(), DetectionLocation.INVENTORY, "DROP"); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void pickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p) plugin.detection().inspectItemEntity(e.getItem(), p, DetectionLocation.PICKUP);
    }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void spawn(ItemSpawnEvent e) {
        if (plugin.config().scanGround() && plugin.config().getIllegalMaterials().contains(e.getEntity().getItemStack().getType())) {
            e.getEntity().remove();
            plugin.getLogger().warning("Removed configured illegal item from ground: " + e.getEntity().getItemStack().getType());
        }
    }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void place(BlockPlaceEvent e) { plugin.detection().inspectCandidate(e.getPlayer(), e.getItemInHand(), DetectionLocation.INVENTORY, "BLOCK_PLACE"); }
    @EventHandler(priority = EventPriority.MONITOR)
    public void command(PlayerCommandPreprocessEvent e) { later(e.getPlayer(), "COMMAND"); }
    @EventHandler(priority = EventPriority.MONITOR)
    public void quit(PlayerQuitEvent e) { plugin.detection().scanPlayer(e.getPlayer(), "LOGOUT"); }
    @EventHandler(priority = EventPriority.MONITOR)
    public void join(PlayerJoinEvent e) { if (plugin.config().get().getBoolean("settings.scan-on-join", true)) later(e.getPlayer(), "JOIN"); }
    @EventHandler(priority = EventPriority.MONITOR)
    public void respawn(PlayerRespawnEvent e) { if (plugin.config().get().getBoolean("settings.scan-after-respawn", true)) later(e.getPlayer(), "RESPAWN"); }
    @EventHandler(priority = EventPriority.MONITOR)
    public void world(PlayerChangedWorldEvent e) { if (plugin.config().get().getBoolean("settings.scan-after-world-change", true)) later(e.getPlayer(), "WORLD_CHANGE"); }
    @EventHandler(priority = EventPriority.MONITOR)
    public void death(PlayerDeathEvent e) { plugin.detection().scanPlayer(e.getEntity(), "DEATH"); }
}
