package com.veinx.autoillegals.detection;

import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;
import java.time.Instant;
import java.util.UUID;

public record DetectionRecord(UUID uuid, String player, MaterialInfo item, int amount, DetectionLocation source,
                              String world, Location location, Instant timestamp, String action, String metadata) {
    public record MaterialInfo(String material) {
        public static MaterialInfo of(ItemStack stack) { return new MaterialInfo(stack.getType().name()); }
    }
}
