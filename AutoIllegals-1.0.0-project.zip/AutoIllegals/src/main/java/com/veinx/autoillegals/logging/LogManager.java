package com.veinx.autoillegals.logging;

import com.veinx.autoillegals.AutoIllegals;
import com.veinx.autoillegals.detection.DetectionRecord;
import org.bukkit.inventory.ItemStack;
import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

public final class LogManager {
    private final AutoIllegals plugin;
    private static final DateTimeFormatter FILE = DateTimeFormatter.ISO_LOCAL_DATE;
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    public LogManager(AutoIllegals plugin) { this.plugin = plugin; }

    public void detection(DetectionRecord r, ItemStack stack) {
        if (!plugin.config().loggingEnabled()) return;
        Path dir = plugin.getDataFolder().toPath().resolve(plugin.config().get().getString("logging.directory", "logs"));
        try {
            Files.createDirectories(dir);
            StringBuilder b = new StringBuilder();
            b.append('[').append(TIME.format(r.timestamp().atZone(ZoneId.systemDefault()))).append("]\n")
             .append("Player: ").append(r.player()).append('\n')
             .append("UUID: ").append(r.uuid()).append('\n')
             .append("Item: ").append(r.item().material()).append('\n')
             .append("Amount: ").append(r.amount()).append('\n')
             .append("Source: ").append(r.source()).append('\n')
             .append("World: ").append(r.world()).append('\n')
             .append("Action: ").append(r.action()).append('\n')
             .append("Metadata: ").append(r.metadata()).append("\n\n");
            Files.writeString(dir.resolve(FILE.format(LocalDate.now()) + ".log"), b, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ex) { plugin.getLogger().log(java.util.logging.Level.WARNING, "Could not write detection log", ex); }
    }
}
