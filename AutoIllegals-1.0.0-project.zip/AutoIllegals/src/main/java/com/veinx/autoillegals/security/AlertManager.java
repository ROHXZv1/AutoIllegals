package com.veinx.autoillegals.security;

import com.veinx.autoillegals.AutoIllegals;
import com.veinx.autoillegals.detection.DetectionRecord;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class AlertManager {
    private final AutoIllegals plugin;
    private final Map<UUID, Boolean> overrides = new ConcurrentHashMap<>();
    public AlertManager(AutoIllegals plugin) { this.plugin = plugin; }
    public void toggle(Player p) { overrides.put(p.getUniqueId(), !enabled(p)); }
    public boolean enabled(Player p) { return overrides.getOrDefault(p.getUniqueId(), plugin.config().defaultAlerts()); }
    public void sendViolation(Player p, String check, int vl) {
        if (!plugin.config().alertsEnabled()) return;
        String msg = plugin.config().msg("violation", Map.of("player", p.getName(), "check", check, "vl", Integer.toString(vl)));
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission(plugin.config().alertPermission()) && enabled(staff)) staff.sendMessage(msg);
        }
    }
    public void send(DetectionRecord r, String trigger) {
        if (!plugin.config().alertsEnabled()) return;
        String template = plugin.config().get().getString("alerts.message", "&8[&bAutoIllegals&8] &fPlayer: &c%player% &7| Detection: &cIllegal Item &7| Item: &c%item% &7| Container: &c%source% &7| Action: &c%duration% ban");
        String msg = org.bukkit.ChatColor.translateAlternateColorCodes('&', template
                .replace("%player%", r.player())
                .replace("%item%", r.item().material())
                .replace("%source%", r.source().name())
                .replace("%duration%", plugin.config().banDurationText()));
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission(plugin.config().alertPermission()) && enabled(staff)) staff.sendMessage(msg);
        }
    }
}
