package com.veinx.autoillegals.command;

import com.veinx.autoillegals.AutoIllegals;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;

public final class CommandManager implements CommandExecutor, TabCompleter {
    private final AutoIllegals plugin;
    public CommandManager(AutoIllegals plugin) { this.plugin = plugin; }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) { help(sender); return true; }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "reload" -> { if (!perm(sender, "autoillegals.reload")) return true; plugin.config().load(); plugin.restartRuntimeTasks(); sender.sendMessage(plugin.config().msg("reload")); }
            case "status" -> { if (!perm(sender, "autoillegals.status")) return true; sender.sendMessage(plugin.config().msg("status", Map.of("enabled", Boolean.toString(plugin.config().enabled()), "ban", Boolean.toString(plugin.config().autoBan()), "items", Integer.toString(plugin.config().getIllegalMaterials().size()), "duration", plugin.config().banDurationText()))); }
            case "alerts" -> { if (!(sender instanceof Player p) || !perm(sender, "autoillegals.alerts")) return true; plugin.alerts().toggle(p); sender.sendMessage(plugin.alerts().enabled(p) ? plugin.config().msg("alerts-on") : plugin.config().msg("alerts-off")); }
            case "check", "scan" -> { if (!perm(sender, "autoillegals." + sub)) return true; Player p = target(args, sender); if (p == null) return true; sender.sendMessage(plugin.config().msg("scan-started", Map.of("player", p.getName())));
                var found = plugin.detection().scanPlayer(p, "MANUAL_" + sub.toUpperCase(Locale.ROOT));
                if (found.isEmpty()) sender.sendMessage(plugin.config().msg("check-clean", Map.of("player", p.getName()))); }
            case "info" -> { if (!perm(sender, "autoillegals.info")) return true; Player p = target(args, sender); if (p == null) return true; sender.sendMessage(ChatColor.AQUA + "AutoIllegals info for " + p.getName()); sender.sendMessage(ChatColor.GRAY + "UUID: " + p.getUniqueId()); sender.sendMessage(ChatColor.GRAY + "World: " + p.getWorld().getName()); sender.sendMessage(ChatColor.GRAY + "Bypass: " + (p.isOp() || p.hasPermission(plugin.config().bypassPermission()))); }
            case "violations" -> { if (!perm(sender, "autoillegals.violations")) return true; Player p = target(args, sender); if (p == null) return true; var all = plugin.violations().all(p); sender.sendMessage(ChatColor.AQUA + "Violations for " + p.getName() + ": " + (all.isEmpty() ? "none" : all)); }
            default -> help(sender);
        }
        return true;
    }

    private Player target(String[] args, CommandSender sender) {
        if (args.length < 2) { sender.sendMessage(ChatColor.RED + "Usage: /autoillegals <check|scan|info|violations> <player>"); return null; }
        Player p = Bukkit.getPlayerExact(args[1]);
        if (p == null) sender.sendMessage(plugin.config().msg("invalid-player", Map.of("player", args[1])));
        return p;
    }
    private boolean perm(CommandSender s, String p) { if (s.hasPermission("autoillegals.admin") || s.hasPermission(p)) return true; s.sendMessage(plugin.config().msg("no-permission")); return false; }
    private void help(CommandSender s) {
        s.sendMessage(ChatColor.AQUA + "AutoIllegals commands:");
        s.sendMessage(ChatColor.GRAY + "/autoillegals reload");
        s.sendMessage(ChatColor.GRAY + "/autoillegals check <player>");
        s.sendMessage(ChatColor.GRAY + "/autoillegals scan <player>");
        s.sendMessage(ChatColor.GRAY + "/autoillegals alerts");
        s.sendMessage(ChatColor.GRAY + "/autoillegals info <player>");
        s.sendMessage(ChatColor.GRAY + "/autoillegals status");
        s.sendMessage(ChatColor.GRAY + "/autoillegals violations <player>");
    }
    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return filter(List.of("reload","check","scan","alerts","info","status","violations"), args[0]);
        if (args.length == 2 && Set.of("check","scan","info","violations").contains(args[0].toLowerCase(Locale.ROOT))) return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[1]);
        return List.of();
    }
    private List<String> filter(List<String> values, String prefix) { return values.stream().filter(s -> s.toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))).sorted().toList(); }
}
