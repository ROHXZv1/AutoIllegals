package com.veinx.autoillegals.detection;

import com.veinx.autoillegals.AutoIllegals;
import org.bukkit.Location;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.BlockStateMeta;

import java.util.*;

public final class InventoryScanner {
    private final AutoIllegals plugin;
    public InventoryScanner(AutoIllegals plugin) { this.plugin = plugin; }

    public Optional<FoundItem> scanPlayer(Player player, boolean includeEnderChest) {
        if (!plugin.config().enabled()) return Optional.empty();
        PlayerInventory inv = player.getInventory();
        ItemStack[] storage = inv.getStorageContents();
        for (int i = 0; i < storage.length; i++) {
            ItemStack item = storage[i];
            DetectionLocation source = i < 9 ? DetectionLocation.HOTBAR : DetectionLocation.INVENTORY;
            Optional<FoundItem> found = inspect(item, source, 0);
            if (found.isPresent()) return found;
        }
        for (ItemStack item : inv.getArmorContents()) {
            Optional<FoundItem> found = inspect(item, DetectionLocation.ARMOR, 0);
            if (found.isPresent()) return found;
        }
        for (ItemStack item : inv.getExtraContents()) {
            Optional<FoundItem> found = inspect(item, DetectionLocation.OFFHAND, 0);
            if (found.isPresent()) return found;
        }
        if (player.getOpenInventory() != null) {
            Optional<FoundItem> found = inspect(player.getOpenInventory().getCursor(), DetectionLocation.CURSOR, 0);
            if (found.isPresent()) return found;
        }
        if (includeEnderChest && plugin.config().scanEnderChests()) {
            Inventory ender = player.getEnderChest();
            Optional<FoundItem> found = inspectInventory(ender, DetectionLocation.ENDER_CHEST, 0);
            if (found.isPresent()) return found;
        }
        return Optional.empty();
    }

    public Optional<FoundItem> scanInventory(Inventory inventory, DetectionLocation source) {
        return inspectInventory(inventory, source, 0);
    }

    private Optional<FoundItem> inspectInventory(Inventory inventory, DetectionLocation source, int depth) {
        for (ItemStack item : inventory.getContents()) {
            Optional<FoundItem> found = inspect(item, source, depth);
            if (found.isPresent()) return found;
        }
        return Optional.empty();
    }

    private Optional<FoundItem> inspect(ItemStack item, DetectionLocation source, int depth) {
        if (item == null || item.getType().isAir()) return Optional.empty();
        if (plugin.config().getIllegalMaterials().contains(item.getType())) {
            return Optional.of(new FoundItem(item, source, null, depth));
        }
        if (plugin.config().recursiveContainers() && depth < plugin.config().maxContainerDepth()) {
            if (item.getItemMeta() instanceof BlockStateMeta meta && meta.getBlockState() instanceof InventoryHolder holder) {
                Inventory nested = holder.getInventory();
                for (int i = 0; i < nested.getSize(); i++) {
                    ItemStack nestedItem = nested.getItem(i);
                    Optional<FoundItem> found = inspect(nestedItem, DetectionLocation.CONTAINER, depth + 1);
                    if (found.isPresent()) return found.map(f -> f.withContainer(meta, holder, i));
                }
            }
        }
        return Optional.empty();
    }

    public record FoundItem(ItemStack item, DetectionLocation source, ContainerRemoval removal, int depth) {
        FoundItem withContainer(BlockStateMeta meta, InventoryHolder holder, int slot) {
            return new FoundItem(item, source, new ContainerRemoval(meta, holder, slot), depth);
        }
    }

    public record ContainerRemoval(BlockStateMeta meta, InventoryHolder holder, int slot) {}
}
