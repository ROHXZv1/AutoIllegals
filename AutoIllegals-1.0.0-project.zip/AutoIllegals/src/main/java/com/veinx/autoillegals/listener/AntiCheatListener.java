package com.veinx.autoillegals.listener;

import com.veinx.autoillegals.AutoIllegals;
import org.bukkit.GameMode;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.block.Action;
import org.bukkit.entity.Player;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class AntiCheatListener implements Listener {
    private final AutoIllegals plugin;
    private final Map<UUID, Long> lastMove = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> inventoryActions = new ConcurrentHashMap<>();
    public AntiCheatListener(AutoIllegals plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void move(PlayerMoveEvent e) {
        if (!plugin.config().checkEnabled("speed") || e.getTo() == null) return;
        Player p = e.getPlayer();
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR || p.isFlying() || p.isGliding()) return;
        long now = System.nanoTime();
        Long prev = lastMove.put(p.getUniqueId(), now);
        if (prev == null) return;
        double seconds = (now - prev) / 1_000_000_000.0;
        if (seconds <= 0 || seconds > 0.5) return;
        double blocks = e.getFrom().distance(e.getTo());
        double bps = blocks / seconds;
        if (bps > plugin.config().checkDouble("speed", "max-blocks-per-second", 22.0)) plugin.violations().add(p, "speed");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void flight(PlayerToggleFlightEvent e) {
        if (!plugin.config().checkEnabled("flight")) return;
        Player p = e.getPlayer();
        if (e.isFlying() && p.getGameMode() == GameMode.SURVIVAL && !p.getAllowFlight()) plugin.violations().add(p, "flight");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void reach(EntityDamageByEntityEvent e) {
        if (!plugin.config().checkEnabled("reach") || !(e.getDamager() instanceof Player p)) return;
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
        double distance = p.getEyeLocation().distance(e.getEntity().getLocation());
        if (distance > plugin.config().checkDouble("reach", "max-distance", 6.0)) plugin.violations().add(p, "reach");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void interact(PlayerInteractEvent e) {
        if (!plugin.config().checkEnabled("impossible-interaction") || e.getClickedBlock() == null || e.getAction() == Action.PHYSICAL) return;
        Player p = e.getPlayer();
        double distance = p.getEyeLocation().distance(e.getClickedBlock().getLocation().add(0.5, 0.5, 0.5));
        if (distance > plugin.config().checkDouble("impossible-interaction", "max-block-distance", 7.0)) plugin.violations().add(p, "impossible-interaction");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void inventory(InventoryClickEvent e) {
        if (!plugin.config().checkEnabled("fast-inventory") || !(e.getWhoClicked() instanceof Player p)) return;
        long second = System.currentTimeMillis() / 1000L;
        String key = p.getUniqueId() + ":" + second;
        // Store the count in the violation map via a local counter map keyed by UUID-second.
        int count = inventoryActions.merge(p.getUniqueId(), 1, Integer::sum);
        if (count > plugin.config().checkInt("fast-inventory", "max-actions-per-second", 35)) plugin.violations().add(p, "fast-inventory");
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> inventoryActions.remove(p.getUniqueId(), count), 20L);
    }
}
