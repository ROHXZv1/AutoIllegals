# AutoIllegals

Production-oriented illegal-item security plugin for Paper 26.2. It uses the Bukkit/Paper API only; no NMS or ProtocolLib dependency is required.

## Requirements
- Paper 1.26.2 / API 26.2
- Java 25

Paper's 26.2 API supports native temporary UUID/profile bans. The plugin calls the native player ban API and kicks the player immediately.

## Build
```bash
mvn clean package
```
The resulting jar is `target/AutoIllegals-1.0.0.jar`.

## Install
1. Put the jar in `plugins/`.
2. Start Paper once to create `plugins/AutoIllegals/`.
3. Review `config.yml` before enabling automatic bans on a production server.
4. Restart the server or use `/autoillegals reload` after changes.

## Commands
- `/autoillegals` - help
- `/autoillegals reload`
- `/autoillegals check <player>`
- `/autoillegals scan <player>`
- `/autoillegals alerts`
- `/autoillegals info <player>`
- `/autoillegals status`
- `/autoillegals violations <player>`

## Permissions
`autoillegals.admin`, `autoillegals.reload`, `autoillegals.check`, `autoillegals.alerts`, `autoillegals.bypass`, `autoillegals.info`, `autoillegals.status`, `autoillegals.violations`, `autoillegals.scan`.

## Detection model
The automatic-ban detector is material/type based by default. Names, enchantments and ordinary item metadata do not make an otherwise allowed material illegal. Optional recursive container scanning inspects `BlockStateMeta` inventories (including shulker-style containers) up to a configured depth.

The detector listens to inventory/player/item events and also performs a configurable periodic safety scan. This avoids an every-tick full-server inventory sweep.

## Anti-cheat
Speed, flight, reach, fast-inventory and impossible-interaction checks are deliberately conservative and alert-only by default. Their configured `action` can be `ALERT`, `KICK`, or `NONE`. They never automatically ban by default.

## Logs
Daily detection logs are written to `plugins/AutoIllegals/logs/`. Logs contain only security-relevant information requested by the plugin configuration.

## Important production note
Do not add an item to `illegal-items` unless your server policy really considers that material restricted. The plugin intentionally does not assume that rare or hard-to-obtain items are illegal.

## Verification note
This project was checked against the published Paper 26.2 API surface. The supplied build environment did not contain Maven or Java 25, so a local `mvn package` build could not be executed here. The `pom.xml` pins Paper API `26.2.build.129-stable` and Java release 25; build it with JDK 25 + Maven on the target build machine.
